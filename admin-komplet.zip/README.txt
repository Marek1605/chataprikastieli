KOMPLETNY ADMIN PANEL - INSTRUKCIE
==================================

SUBORY A KAM ICH NAHRAT:
- AdminContext.tsx -> /root/chataprikastieli/lib/AdminContext.tsx
- AdminSidebar.tsx -> /root/chataprikastieli/components/AdminSidebar.tsx
- Providers.tsx    -> /root/chataprikastieli/components/Providers.tsx
- Gallery.tsx      -> /root/chataprikastieli/components/Gallery.tsx

PO NAHRATI SPUSTI:
cd /root/chataprikastieli
git add -A
git commit -m "Complete admin panel"
git push

HESLO: ChataAdmin2025!

FUNKCIE:
- Hero: titulok, podtitulok, pozadie
- Galeria: pridavanie, mazanie, presuvanie obrazkov
- Cennik: ceny a pocet noci pre balicky
- Recenzie: pridavanie, mazanie, upravovanie
- FAQ: pridavanie, mazanie, upravovanie
- Kontakt: telefon, email, adresa, check-in/out
- Nastavenia: reset na predvolene
