'use client';

import { useState, useRef, useEffect } from 'react';
import { useAdmin } from '@/lib/AdminContext';

type Tab = 'hero' | 'contact' | 'gallery' | 'pricing' | 'reviews' | 'faq' | 'settings';

export default function AdminSidebar() {
  const {
    isAdmin, isEditing, login, logout, toggleEditing,
    content, updateContent,
    addGalleryImage, removeGalleryImage, updateGalleryImage, moveGalleryImage,
    addReview, removeReview, updateReview,
    addFAQ, removeFAQ, updateFAQ,
    saveAll, resetToDefaults, exportData, importData, hasUnsavedChanges,
  } = useAdmin();

  const [showLogin, setShowLogin] = useState(false);
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [collapsed, setCollapsed] = useState(false);
  const [hidden, setHidden] = useState(true);
  const [activeTab, setActiveTab] = useState<Tab>('hero');
  const [newImageUrl, setNewImageUrl] = useState('');
  const [saveFlash, setSaveFlash] = useState(false);
  const [editingImage, setEditingImage] = useState<string | null>(null);
  const [uploadStatus, setUploadStatus] = useState<string>('');
  
  const fileRef = useRef<HTMLInputElement>(null);
  const importRef = useRef<HTMLInputElement>(null);

  // Keyboard: Ctrl+Shift+A
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.ctrlKey && e.shiftKey && e.key === 'A') {
        e.preventDefault();
        isAdmin ? setHidden(h => !h) : setShowLogin(true);
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [isAdmin]);

  useEffect(() => { if (isAdmin) setHidden(false); }, [isAdmin]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (login(password)) {
      setShowLogin(false);
      setPassword('');
      setError('');
    } else {
      setError('Nesprávne heslo');
    }
  };

  const handleSave = () => {
    saveAll();
    setSaveFlash(true);
    setTimeout(() => setSaveFlash(false), 2000);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    // Check file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      setUploadStatus('❌ Súbor je príliš veľký (max 5MB)');
      setTimeout(() => setUploadStatus(''), 3000);
      return;
    }
    
    setUploadStatus('⏳ Nahrávam...');
    
    const reader = new FileReader();
    reader.onload = (ev) => {
      const result = ev.target?.result as string;
      addGalleryImage(result, file.name.replace(/\.[^/.]+$/, ''));
      setUploadStatus('✅ Obrázok pridaný!');
      setTimeout(() => setUploadStatus(''), 2000);
    };
    reader.onerror = () => {
      setUploadStatus('❌ Chyba pri nahrávaní');
      setTimeout(() => setUploadStatus(''), 3000);
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleExport = () => {
    const blob = new Blob([exportData()], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `chata-backup-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
  };

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      importData(ev.target?.result as string) ? alert('✅ Import úspešný!') : alert('❌ Chyba importu');
    };
    reader.readAsText(file);
  };

  // ========== LOGIN BUTTON - VIDITEĽNÝ ==========
  if (!isAdmin) {
    return (
      <>
        {/* Viditeľné tlačidlo */}
        <button
          onClick={() => setShowLogin(true)}
          className="fixed bottom-4 left-4 w-12 h-12 rounded-xl bg-gray-800/80 hover:bg-gray-700 backdrop-blur-sm flex items-center justify-center z-50 transition-all hover:scale-110 shadow-xl border border-white/10"
          title="Admin panel (Ctrl+Shift+A)"
        >
          <span className="text-xl">⚙️</span>
        </button>

        {showLogin && (
          <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-[300] p-4" onClick={() => setShowLogin(false)}>
            <div className="bg-[#1a1a1a] rounded-2xl p-6 w-full max-w-sm shadow-2xl border border-white/10" onClick={e => e.stopPropagation()}>
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-gradient-to-br from-amber-500 to-orange-600 rounded-xl flex items-center justify-center text-white text-xl">🏔️</div>
                <div>
                  <h2 className="font-bold text-white text-lg">Admin Panel</h2>
                  <p className="text-xs text-gray-400">Správa obsahu webu</p>
                </div>
              </div>
              
              <form onSubmit={handleLogin}>
                <input
                  type="password"
                  value={password}
                  onChange={e => { setPassword(e.target.value); setError(''); }}
                  placeholder="Zadajte heslo..."
                  className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl mb-3 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                  autoFocus
                />
                {error && <p className="text-red-400 text-xs mb-3 flex items-center gap-1">⚠️ {error}</p>}
                <button type="submit" className="w-full py-3 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white font-semibold rounded-xl transition-all">
                  Prihlásiť sa
                </button>
              </form>
              
              <button onClick={() => setShowLogin(false)} className="w-full mt-3 py-2 text-gray-500 hover:text-gray-300 text-sm">
                Zrušiť
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  // ========== HIDDEN STATE ==========
  if (hidden) {
    return (
      <button
        onClick={() => setHidden(false)}
        className="fixed top-1/2 -translate-y-1/2 left-0 z-[200] bg-gray-900 hover:bg-gray-800 text-white w-8 py-8 rounded-r-xl shadow-xl transition-all hover:w-10 border-r border-t border-b border-white/10"
        title="Otvoriť admin panel"
      >
        <svg className="w-4 h-4 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
        </svg>
      </button>
    );
  }

  // ========== TABS ==========
  const tabs: { id: Tab; icon: string; label: string }[] = [
    { id: 'hero', icon: '🏠', label: 'Hero' },
    { id: 'contact', icon: '📞', label: 'Kontakt' },
    { id: 'gallery', icon: '🖼️', label: 'Galéria' },
    { id: 'pricing', icon: '💰', label: 'Cenník' },
    { id: 'reviews', icon: '⭐', label: 'Recenzie' },
    { id: 'faq', icon: '❓', label: 'FAQ' },
    { id: 'settings', icon: '⚙️', label: 'Nastavenia' },
  ];

  const w = collapsed ? 'w-16' : 'w-80';

  // ========== MAIN SIDEBAR ==========
  return (
    <>
      <aside className={`fixed top-0 left-0 h-full ${w} bg-[#1a1a1a] text-white z-[200] transition-all duration-300 flex flex-col shadow-2xl border-r border-white/5`}>
        
        {/* HEADER */}
        <div className="flex items-center justify-between p-3 border-b border-white/10">
          {!collapsed && (
            <div className="flex items-center gap-2 min-w-0">
              <div className="w-9 h-9 bg-gradient-to-br from-amber-500 to-orange-600 rounded-lg flex items-center justify-center text-base shrink-0">🏔️</div>
              <div className="min-w-0">
                <p className="text-sm font-bold truncate">Chata Admin</p>
                <p className="text-[10px] text-gray-500 truncate">Správa webu</p>
              </div>
            </div>
          )}
          <div className="flex gap-1 shrink-0">
            <button onClick={() => setCollapsed(!collapsed)} className="p-2 hover:bg-white/10 rounded-lg" title={collapsed ? 'Rozbaliť' : 'Zbaliť'}>
              <svg className={`w-4 h-4 transition-transform ${collapsed ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 19l-7-7 7-7m8 14l-7-7 7-7" />
              </svg>
            </button>
            <button onClick={() => setHidden(true)} className="p-2 hover:bg-white/10 rounded-lg" title="Schovať">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>

        {/* SAVE BUTTON */}
        <div className={`p-2 border-b border-white/10 ${collapsed ? 'flex flex-col gap-1' : 'flex gap-2'}`}>
          <button
            onClick={handleSave}
            className={`${collapsed ? 'p-3' : 'flex-1 py-3 px-4'} rounded-xl font-semibold transition-all flex items-center justify-center gap-2 ${
              saveFlash ? 'bg-green-500 text-white' 
              : hasUnsavedChanges ? 'bg-amber-500 hover:bg-amber-400 text-black' 
              : 'bg-white/10 hover:bg-white/20 text-white'
            }`}
            title="Uložiť zmeny"
          >
            <span className="text-lg">{saveFlash ? '✓' : '💾'}</span>
            {!collapsed && (saveFlash ? 'Uložené!' : hasUnsavedChanges ? 'ULOŽIŤ*' : 'Uložené')}
          </button>
        </div>

        {/* TABS */}
        <div className={`${collapsed ? 'flex flex-col' : 'grid grid-cols-4'} gap-1 p-2 border-b border-white/10`}>
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => { setActiveTab(tab.id); if (collapsed) setCollapsed(false); }}
              className={`flex items-center justify-center p-2.5 rounded-lg text-xs font-medium transition-all ${
                activeTab === tab.id ? 'bg-amber-500/20 text-amber-400' : 'text-gray-500 hover:text-white hover:bg-white/5'
              }`}
              title={tab.label}
            >
              <span className="text-base">{tab.icon}</span>
            </button>
          ))}
        </div>

        {/* TAB CONTENT */}
        {!collapsed && (
          <div className="flex-1 overflow-y-auto p-3 space-y-4">
            
            {/* ===== HERO TAB ===== */}
            {activeTab === 'hero' && (
              <>
                <Section title="🏠 Hero sekcia">
                  <Field label="Hlavný nadpis" value={content.hero.title} onChange={v => updateContent('hero.title', v)} />
                  <TextArea label="Podnadpis" value={content.hero.subtitle} onChange={v => updateContent('hero.subtitle', v)} rows={3} />
                  <ImageField 
                    label="Pozadie (hero obrázok)" 
                    value={content.hero.backgroundImage} 
                    onChange={v => updateContent('hero.backgroundImage', v)} 
                  />
                </Section>
                
                <div className="p-3 bg-green-500/10 border border-green-500/30 rounded-xl">
                  <p className="text-xs text-green-400">
                    💡 Zmeny sa prejavia <strong>okamžite</strong> na stránke. Nezabudni ich uložiť!
                  </p>
                </div>
              </>
            )}

            {/* ===== CONTACT TAB ===== */}
            {activeTab === 'contact' && (
              <>
                <Section title="📞 Kontaktné údaje">
                  <Field label="Telefón" value={content.contact.phone} onChange={v => updateContent('contact.phone', v)} icon="📞" />
                  <Field label="Email" value={content.contact.email} onChange={v => updateContent('contact.email', v)} icon="✉️" />
                  <Field label="Adresa" value={content.contact.address} onChange={v => updateContent('contact.address', v)} icon="📍" />
                </Section>
                
                <Section title="🕐 Prevádzka">
                  <div className="grid grid-cols-2 gap-2">
                    <Field label="Check-in" value={content.booking.checkIn} onChange={v => updateContent('booking.checkIn', v)} />
                    <Field label="Check-out" value={content.booking.checkOut} onChange={v => updateContent('booking.checkOut', v)} />
                  </div>
                </Section>
              </>
            )}

            {/* ===== GALLERY TAB ===== */}
            {activeTab === 'gallery' && (
              <>
                <Section title={`🖼️ Galéria (${content.gallery.length} fotiek)`}>
                  {/* Upload status */}
                  {uploadStatus && (
                    <div className={`p-2 rounded-lg text-xs font-medium text-center ${
                      uploadStatus.includes('✅') ? 'bg-green-500/20 text-green-400' :
                      uploadStatus.includes('❌') ? 'bg-red-500/20 text-red-400' :
                      'bg-blue-500/20 text-blue-400'
                    }`}>
                      {uploadStatus}
                    </div>
                  )}
                  
                  {/* Add by URL */}
                  <div className="flex gap-1 mb-2">
                    <input
                      type="text"
                      value={newImageUrl}
                      onChange={e => setNewImageUrl(e.target.value)}
                      placeholder="URL obrázka..."
                      className="flex-1 px-3 py-2.5 bg-white/5 border border-white/10 rounded-lg text-xs text-white placeholder-gray-500 focus:outline-none focus:ring-1 focus:ring-amber-500"
                    />
                    <button 
                      onClick={() => { 
                        if (newImageUrl.trim()) { 
                          addGalleryImage(newImageUrl.trim()); 
                          setNewImageUrl(''); 
                        } 
                      }} 
                      className="px-4 bg-amber-500 hover:bg-amber-400 rounded-lg text-xs font-bold text-black"
                    >
                      +
                    </button>
                  </div>
                  
                  {/* Upload file */}
                  <button 
                    onClick={() => fileRef.current?.click()} 
                    className="w-full py-3 bg-gradient-to-r from-amber-500/20 to-orange-500/20 hover:from-amber-500/30 hover:to-orange-500/30 rounded-xl text-xs font-medium flex items-center justify-center gap-2 border border-dashed border-amber-500/50 mb-3"
                  >
                    📁 Nahrať obrázok z počítača
                  </button>
                  <input 
                    ref={fileRef} 
                    type="file" 
                    accept="image/jpeg,image/png,image/gif,image/webp" 
                    onChange={handleFileUpload} 
                    className="hidden" 
                  />

                  {/* Grid */}
                  <div className="grid grid-cols-3 gap-2">
                    {content.gallery.map((img, i) => (
                      <div key={img.id} className="relative group">
                        <div className="aspect-square bg-white/5 rounded-lg overflow-hidden">
                          <img 
                            src={img.src} 
                            alt={img.alt} 
                            className="w-full h-full object-cover" 
                            onError={e => { 
                              (e.target as HTMLImageElement).src = 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="60" height="60"><rect fill="%23333" width="60" height="60"/><text fill="%23666" x="50%" y="50%" text-anchor="middle" dy=".3em" font-size="10">?</text></svg>'; 
                            }} 
                          />
                        </div>
                        
                        {/* Hover */}
                        <div className="absolute inset-0 bg-black/80 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg flex flex-col items-center justify-center gap-1 p-1">
                          <span className="text-[9px] text-gray-400 font-bold">#{i + 1}</span>
                          <div className="flex gap-1">
                            {i > 0 && <button onClick={() => moveGalleryImage(i, i - 1)} className="w-6 h-6 bg-white/20 hover:bg-white/40 rounded text-[10px]">←</button>}
                            <button onClick={() => setEditingImage(img.id)} className="w-6 h-6 bg-amber-500 hover:bg-amber-400 rounded text-[10px] text-black font-bold">✎</button>
                            <button onClick={() => removeGalleryImage(img.id)} className="w-6 h-6 bg-red-500 hover:bg-red-400 rounded text-[10px]">✕</button>
                            {i < content.gallery.length - 1 && <button onClick={() => moveGalleryImage(i, i + 1)} className="w-6 h-6 bg-white/20 hover:bg-white/40 rounded text-[10px]">→</button>}
                          </div>
                        </div>

                        {/* Edit modal */}
                        {editingImage === img.id && (
                          <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-[300] p-4" onClick={() => setEditingImage(null)}>
                            <div className="bg-[#2a2a2a] rounded-xl p-4 w-full max-w-md space-y-3" onClick={e => e.stopPropagation()}>
                              <div className="flex items-center justify-between">
                                <p className="font-bold">Upraviť obrázok #{i + 1}</p>
                                <button onClick={() => setEditingImage(null)} className="text-gray-400 hover:text-white">✕</button>
                              </div>
                              <div className="aspect-video bg-black/50 rounded-lg overflow-hidden">
                                <img src={img.src} alt={img.alt} className="w-full h-full object-contain" />
                              </div>
                              <Field label="URL obrázka" value={img.src} onChange={v => updateGalleryImage(img.id, { src: v })} />
                              <Field label="Alt text (popis)" value={img.alt} onChange={v => updateGalleryImage(img.id, { alt: v })} />
                              <button onClick={() => setEditingImage(null)} className="w-full py-2.5 bg-amber-500 hover:bg-amber-400 rounded-lg text-sm font-bold text-black">Hotovo</button>
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </Section>
              </>
            )}

            {/* ===== PRICING TAB ===== */}
            {activeTab === 'pricing' && (
              <>
                {(['weekend', 'reset', 'week'] as const).map((pkg, i) => (
                  <Section key={pkg} title={['🌙 Víkendový pobyt', '⭐ Reset pobyt', '📅 Týždenný pobyt'][i]}>
                    <div className="grid grid-cols-2 gap-3">
                      <Field label="Počet nocí" type="number" value={String(content.pricing[pkg].nights)} onChange={v => updateContent(`pricing.${pkg}.nights`, parseInt(v) || 0)} />
                      <Field label="Cena (€)" type="number" value={String(content.pricing[pkg].price)} onChange={v => updateContent(`pricing.${pkg}.price`, parseInt(v) || 0)} />
                    </div>
                  </Section>
                ))}
              </>
            )}

            {/* ===== REVIEWS TAB ===== */}
            {activeTab === 'reviews' && (
              <>
                <Section title={`⭐ Recenzie (${content.reviews.length})`}>
                  <button 
                    onClick={() => addReview({ name: 'Nový hosť', date: 'Mesiac 2024', text: 'Skvelý pobyt!', rating: 5 })}
                    className="w-full py-2.5 bg-green-600 hover:bg-green-500 rounded-xl text-sm font-bold mb-4"
                  >
                    + Pridať novú recenziu
                  </button>
                  
                  <div className="space-y-3">
                    {content.reviews.map((review, i) => (
                      <div key={review.id} className="bg-white/5 rounded-xl p-3 space-y-2 border border-white/5">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-amber-400">Recenzia #{i + 1}</span>
                          <button onClick={() => removeReview(review.id)} className="text-red-400 hover:text-red-300 text-xs px-2 py-1 hover:bg-red-500/20 rounded">🗑️</button>
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <Field label="Meno" value={review.name} onChange={v => updateReview(review.id, { name: v })} small />
                          <Field label="Dátum" value={review.date} onChange={v => updateReview(review.id, { date: v })} small />
                        </div>
                        <TextArea label="Text" value={review.text} onChange={v => updateReview(review.id, { text: v })} rows={2} small />
                        <div>
                          <label className="text-[10px] text-gray-400 block mb-1">Hodnotenie</label>
                          <div className="flex gap-1">
                            {[1, 2, 3, 4, 5].map(n => (
                              <button
                                key={n}
                                onClick={() => updateReview(review.id, { rating: n })}
                                className={`w-8 h-8 rounded-lg text-lg ${review.rating >= n ? 'bg-yellow-500 text-black' : 'bg-white/10 text-gray-500'}`}
                              >
                                ★
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </Section>
              </>
            )}

            {/* ===== FAQ TAB ===== */}
            {activeTab === 'faq' && (
              <>
                <Section title={`❓ FAQ (${content.faq.length})`}>
                  <button 
                    onClick={() => addFAQ({ question: 'Nová otázka?', answer: 'Odpoveď...' })}
                    className="w-full py-2.5 bg-green-600 hover:bg-green-500 rounded-xl text-sm font-bold mb-4"
                  >
                    + Pridať novú otázku
                  </button>
                  
                  <div className="space-y-3">
                    {content.faq.map((item, i) => (
                      <div key={item.id} className="bg-white/5 rounded-xl p-3 space-y-2 border border-white/5">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-amber-400">FAQ #{i + 1}</span>
                          <button onClick={() => removeFAQ(item.id)} className="text-red-400 hover:text-red-300 text-xs px-2 py-1 hover:bg-red-500/20 rounded">🗑️</button>
                        </div>
                        <Field label="Otázka" value={item.question} onChange={v => updateFAQ(item.id, { question: v })} small />
                        <TextArea label="Odpoveď" value={item.answer} onChange={v => updateFAQ(item.id, { answer: v })} rows={2} small />
                      </div>
                    ))}
                  </div>
                </Section>
              </>
            )}

            {/* ===== SETTINGS TAB ===== */}
            {activeTab === 'settings' && (
              <>
                <Section title="💾 Záloha">
                  <button onClick={handleExport} className="w-full py-3 bg-blue-600 hover:bg-blue-500 rounded-xl text-sm font-bold flex items-center justify-center gap-2 mb-2">
                    📥 Stiahnuť zálohu (JSON)
                  </button>
                  <button onClick={() => importRef.current?.click()} className="w-full py-3 bg-white/5 hover:bg-white/10 rounded-xl text-sm font-medium flex items-center justify-center gap-2 border border-dashed border-white/20">
                    📤 Nahrať zálohu
                  </button>
                  <input ref={importRef} type="file" accept=".json" onChange={handleImport} className="hidden" />
                </Section>

                <Section title="⚠️ Nebezpečná zóna">
                  <button 
                    onClick={() => confirm('Naozaj resetovať všetko?') && resetToDefaults()} 
                    className="w-full py-3 bg-red-600/50 hover:bg-red-600 rounded-xl text-sm font-bold"
                  >
                    🗑️ Resetovať na predvolené
                  </button>
                </Section>

                <Section title="ℹ️ Info">
                  <div className="bg-white/5 rounded-xl p-4 space-y-3 text-sm">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-400">Heslo:</span>
                      <code className="bg-amber-500/20 text-amber-400 px-2 py-1 rounded text-xs">ChataAdmin2025!</code>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-400">Skratka:</span>
                      <code className="bg-white/10 px-2 py-1 rounded text-xs">Ctrl+Shift+A</code>
                    </div>
                  </div>
                </Section>
              </>
            )}
          </div>
        )}

        {/* FOOTER */}
        <div className={`border-t border-white/10 p-2 ${collapsed ? 'flex flex-col gap-1' : 'flex items-center'}`}>
          {collapsed ? (
            <>
              <button onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} className="p-2.5 hover:bg-white/10 rounded-lg flex justify-center" title="Na vrch">⬆️</button>
              <button onClick={logout} className="p-2.5 hover:bg-red-600/30 rounded-lg flex justify-center" title="Odhlásiť">🚪</button>
            </>
          ) : (
            <>
              <button onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} className="p-2 hover:bg-white/10 rounded-lg">⬆️</button>
              <div className="flex-1" />
              <button onClick={logout} className="flex items-center gap-2 px-4 py-2 hover:bg-red-600/30 rounded-lg text-sm text-gray-400 hover:text-white">
                🚪 Odhlásiť
              </button>
            </>
          )}
        </div>
      </aside>

      {/* Unsaved warning */}
      {hasUnsavedChanges && (
        <div className="fixed bottom-4 right-4 z-[190] bg-amber-500 text-black px-4 py-2 rounded-xl text-sm font-bold shadow-xl flex items-center gap-2">
          ⚠️ Neuložené zmeny!
        </div>
      )}
    </>
  );
}

// ========== HELPERS ==========
function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="space-y-3">
      <p className="text-xs font-bold text-gray-400 uppercase tracking-wider">{title}</p>
      {children}
    </div>
  );
}

function Field({ label, value, onChange, icon, type = 'text', small }: { label: string; value: string; onChange: (v: string) => void; icon?: string; type?: string; small?: boolean }) {
  return (
    <div>
      <label className={`${small ? 'text-[10px]' : 'text-xs'} text-gray-400 block mb-1.5`}>{icon && <span className="mr-1">{icon}</span>}{label}</label>
      <input
        type={type}
        value={value}
        onChange={e => onChange(e.target.value)}
        className={`w-full ${small ? 'px-2.5 py-2 text-xs' : 'px-3 py-2.5 text-sm'} bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent`}
      />
    </div>
  );
}

function TextArea({ label, value, onChange, rows = 3, small }: { label: string; value: string; onChange: (v: string) => void; rows?: number; small?: boolean }) {
  return (
    <div>
      <label className={`${small ? 'text-[10px]' : 'text-xs'} text-gray-400 block mb-1.5`}>{label}</label>
      <textarea
        value={value}
        onChange={e => onChange(e.target.value)}
        rows={rows}
        className={`w-full ${small ? 'px-2.5 py-2 text-xs' : 'px-3 py-2.5 text-sm'} bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent resize-y`}
      />
    </div>
  );
}

function ImageField({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  const [showUrl, setShowUrl] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const [status, setStatus] = useState('');

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    if (file.size > 5 * 1024 * 1024) {
      setStatus('❌ Max 5MB');
      setTimeout(() => setStatus(''), 3000);
      return;
    }
    
    setStatus('⏳ Nahrávam...');
    const reader = new FileReader();
    reader.onload = (ev) => {
      onChange(ev.target?.result as string);
      setStatus('✅ Hotovo!');
      setTimeout(() => setStatus(''), 2000);
    };
    reader.readAsDataURL(file);
  };

  return (
    <div>
      <label className="text-xs text-gray-400 block mb-1.5">{label}</label>
      <div className="space-y-2">
        <div className="aspect-video bg-white/5 rounded-xl overflow-hidden border border-white/10">
          <img src={value} alt="" className="w-full h-full object-cover" onError={e => { (e.target as HTMLImageElement).style.opacity = '0.3'; }} />
        </div>
        {status && <p className={`text-xs text-center ${status.includes('✅') ? 'text-green-400' : status.includes('❌') ? 'text-red-400' : 'text-blue-400'}`}>{status}</p>}
        <div className="flex gap-2">
          <button onClick={() => setShowUrl(!showUrl)} className="flex-1 py-2 bg-white/5 hover:bg-white/10 rounded-lg text-xs font-medium">
            {showUrl ? '✕ Zavrieť' : '🔗 URL'}
          </button>
          <button onClick={() => fileRef.current?.click()} className="flex-1 py-2 bg-amber-500/20 hover:bg-amber-500/30 rounded-lg text-xs font-medium text-amber-400">
            📁 Nahrať
          </button>
          <input ref={fileRef} type="file" accept="image/*" onChange={handleFile} className="hidden" />
        </div>
        {showUrl && (
          <input
            type="text"
            value={value}
            onChange={e => onChange(e.target.value)}
            className="w-full px-3 py-2.5 bg-white/5 border border-white/10 rounded-lg text-sm text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
            placeholder="https://..."
          />
        )}
      </div>
    </div>
  );
}
