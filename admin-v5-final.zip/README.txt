INŠTRUKCIE PRE NAHRATIE:
=========================

1. Nahraj tieto súbory do /root/chataprikastieli/:

   Gallery.tsx      ->  components/Gallery.tsx
   AdminSidebar.tsx ->  components/AdminSidebar.tsx
   Hero.tsx         ->  components/Hero.tsx
   Providers.tsx    ->  components/Providers.tsx
   config.ts        ->  lib/config.ts

2. Spusti:
   cd /root/chataprikastieli
   git add -A
   git commit -m "Admin v5 inline editing"
   git push

3. Počkaj na Coolify redeploy

TESTOVANIE:
- Klikni na ⚙️ vľavo dole
- Heslo: ChataAdmin2025!
- Po prihlásení prejdi myšou cez obrázky v galérii
- Zobrazí sa ✏️ Upraviť a 🗑️ Zmazať
