OPRAVA KOMPONENTOV - CITANIE Z ADMIN CONTEXTU
=============================================

SUBORY:
- Hero.tsx        -> /root/chataprikastieli/components/Hero.tsx
- Gallery.tsx     -> /root/chataprikastieli/components/Gallery.tsx
- EditableText.tsx -> /root/chataprikastieli/components/EditableText.tsx

PO NAHRATI:
cd /root/chataprikastieli
git add -A
git commit -m "Components read from AdminContext"
git push

TOTO OPRAVI:
- Hero cita titulok, podtitulok, pozadie z AdminContext
- Gallery cita obrazky z AdminContext
- Zmeny v admin paneli sa premietnu na stranke
