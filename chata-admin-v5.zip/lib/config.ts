// Opravené cesty k obrázkom podľa skutočných súborov na serveri
export const galleryImages = [
  { src: '/assets/gallery-1.jpg', alt: 'Interiér chaty' },
  { src: '/assets/gallery-2.jpg', alt: 'Obývačka' },
  { src: '/assets/gallery-3.jpg', alt: 'Spálňa' },
  { src: '/assets/gallery-4.jpg', alt: 'Kuchyňa' },
  { src: '/assets/surrounding-2.jpg', alt: 'Okolie' },
  { src: '/assets/surrounding-3.jpg', alt: 'Príroda' },
  { src: '/assets/surrounding-4.jpg', alt: 'Výhľad' },
  { src: '/assets/surrounding-5.jpg', alt: 'Les' },
  { src: '/assets/surrounding-6.jpg', alt: 'Hory' },
  { src: '/assets/surrounding-8.jpg', alt: 'Panoráma' },
];

export const siteConfig = {
  name: 'Chata pri Kaštieli',
  description: 'Luxusná horská chata v Turci',
  url: 'https://chataprikastieli.sk',
};
