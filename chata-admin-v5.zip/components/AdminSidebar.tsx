'use client';

import { useState, useEffect } from 'react';

const ADMIN_PASSWORD = 'ChataAdmin2025!';
const STORAGE_KEY = 'chata_admin_v5';

export default function AdminSidebar() {
  const [isAdmin, setIsAdmin] = useState(false);
  const [showLogin, setShowLogin] = useState(false);
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    if (sessionStorage.getItem('chata_admin') === 'true') {
      setIsAdmin(true);
    }
  }, []);

  // Keyboard shortcut
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.ctrlKey && e.shiftKey && e.key === 'A') {
        e.preventDefault();
        if (isAdmin) {
          handleLogout();
        } else {
          setShowLogin(true);
        }
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [isAdmin]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === ADMIN_PASSWORD) {
      setIsAdmin(true);
      sessionStorage.setItem('chata_admin', 'true');
      setShowLogin(false);
      setPassword('');
      setError('');
      window.location.reload(); // Reload to show admin mode
    } else {
      setError('Nesprávne heslo');
    }
  };

  const handleLogout = () => {
    setIsAdmin(false);
    sessionStorage.removeItem('chata_admin');
    window.location.reload();
  };

  const handleReset = () => {
    if (confirm('Resetovať všetky zmeny na predvolené hodnoty?')) {
      localStorage.removeItem(STORAGE_KEY);
      window.location.reload();
    }
  };

  const handleExport = () => {
    const data = localStorage.getItem(STORAGE_KEY) || '{}';
    const blob = new Blob([data], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `chata-backup-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
  };

  // Login button (bottom left)
  if (!isAdmin) {
    return (
      <>
        <button
          onClick={() => setShowLogin(true)}
          className="fixed bottom-4 left-4 w-14 h-14 rounded-xl bg-gray-800/80 hover:bg-gray-700 flex items-center justify-center z-50 shadow-xl border-2 border-amber-500/50 text-2xl transition-all hover:scale-110"
          title="Admin panel (Ctrl+Shift+A)"
        >
          ⚙️
        </button>

        {showLogin && (
          <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-[500] p-4" onClick={() => setShowLogin(false)}>
            <div className="bg-white rounded-2xl p-6 w-full max-w-sm shadow-2xl" onClick={e => e.stopPropagation()}>
              <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">🏔️ Admin Panel</h2>
              <form onSubmit={handleLogin}>
                <input
                  type="password"
                  value={password}
                  onChange={e => { setPassword(e.target.value); setError(''); }}
                  placeholder="Zadaj heslo..."
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl mb-3 text-lg focus:border-amber-500 focus:outline-none"
                  autoFocus
                />
                {error && <p className="text-red-500 text-sm mb-3">⚠️ {error}</p>}
                <button type="submit" className="w-full py-3 bg-amber-500 hover:bg-amber-600 text-white font-bold rounded-xl text-lg transition-colors">
                  Prihlásiť sa
                </button>
              </form>
              <p className="text-center text-gray-400 text-sm mt-4">Ctrl+Shift+A pre rýchle prihlásenie</p>
            </div>
          </div>
        )}
      </>
    );
  }

  // Admin toolbar (top bar when logged in)
  return (
    <div className="fixed top-0 left-0 right-0 z-[400] bg-gradient-to-r from-amber-600 to-orange-600 text-white shadow-lg">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-3">
          <span className="font-bold text-lg">🔧 Admin režim</span>
          <span className="text-amber-200 text-sm hidden sm:inline">Prihlásený • Klikni na obrázky pre úpravu</span>
        </div>
        
        <div className="flex items-center gap-2">
          <button
            onClick={handleExport}
            className="px-3 py-1.5 bg-white/20 hover:bg-white/30 rounded-lg text-sm font-medium"
          >
            📥 Export
          </button>
          <button
            onClick={handleReset}
            className="px-3 py-1.5 bg-red-500/50 hover:bg-red-500 rounded-lg text-sm font-medium"
          >
            🗑️ Reset
          </button>
          <button
            onClick={handleLogout}
            className="px-3 py-1.5 bg-white/20 hover:bg-white/30 rounded-lg text-sm font-medium"
          >
            🚪 Odhlásiť
          </button>
        </div>
      </div>
    </div>
  );
}
