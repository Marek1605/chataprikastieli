import { NextRequest, NextResponse } from 'next/server';
import { promises as fs } from 'fs';
import path from 'path';
import crypto from 'crypto';

const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'ChataAdmin2025!';
const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB
const ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/avif'];

const MAGIC: Record<string, number[]> = {
  'image/jpeg': [0xFF, 0xD8, 0xFF],
  'image/png': [0x89, 0x50, 0x4E, 0x47],
  'image/webp': [0x52, 0x49, 0x46, 0x46],
};

function verifyAuth(req: NextRequest): boolean {
  return req.headers.get('x-admin-token') === ADMIN_PASSWORD;
}

async function getUploadDir(): Promise<{ dir: string; prefix: string }> {
  const candidates = [
    { dir: path.join(process.cwd(), 'public', 'uploads'), prefix: '/uploads/' },
    { dir: '/app/public/uploads', prefix: '/uploads/' },
    { dir: '/tmp/uploads', prefix: '/api/admin-upload?f=' },
  ];

  for (const candidate of candidates) {
    try {
      await fs.mkdir(candidate.dir, { recursive: true });
      const testFile = path.join(candidate.dir, '.write-test');
      await fs.writeFile(testFile, 'ok');
      await fs.unlink(testFile);
      return candidate;
    } catch { continue; }
  }
  throw new Error('No writable upload directory');
}

// POST - upload image file
export async function POST(req: NextRequest) {
  if (!verifyAuth(req)) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const formData = await req.formData();
    const file = formData.get('file') as File | null;

    if (!file) {
      return NextResponse.json({ error: 'No file provided' }, { status: 400 });
    }

    // Validate type
    if (!ALLOWED_TYPES.includes(file.type)) {
      return NextResponse.json({ error: 'Invalid file type. Allowed: JPEG, PNG, WebP, AVIF' }, { status: 400 });
    }

    // Validate size
    if (file.size > MAX_FILE_SIZE) {
      return NextResponse.json({ error: 'File too large. Max 10MB.' }, { status: 400 });
    }

    const buffer = Buffer.from(await file.arrayBuffer());

    // Verify magic bytes
    const expected = MAGIC[file.type];
    if (expected) {
      const matches = expected.every((byte, i) => buffer[i] === byte);
      if (!matches) {
        return NextResponse.json({ error: 'File content does not match type' }, { status: 400 });
      }
    }

    // Generate unique filename
    const hash = crypto.createHash('md5').update(buffer).digest('hex').slice(0, 8);
    const ext = file.type === 'image/png' ? '.png'
      : file.type === 'image/webp' ? '.webp'
      : file.type === 'image/avif' ? '.avif'
      : '.jpg';
    const filename = `${Date.now()}-${hash}${ext}`;

    // Save file
    const { dir, prefix } = await getUploadDir();
    const filePath = path.join(dir, filename);
    await fs.writeFile(filePath, buffer);

    const url = prefix + filename;
    console.log(`Uploaded: ${filePath} -> ${url} (${Math.round(file.size / 1024)}KB)`);

    return NextResponse.json({ success: true, url, filename, size: file.size });
  } catch (err: any) {
    console.error('Upload error:', err);
    return NextResponse.json({ error: err.message || 'Upload failed' }, { status: 500 });
  }
}

// GET - serve files from /tmp/uploads (fallback when public/uploads not writable)
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const filename = searchParams.get('f');
  
  if (!filename || filename.includes('..') || filename.includes('/')) {
    return NextResponse.json({ error: 'Invalid filename' }, { status: 400 });
  }

  try {
    const filePath = path.join('/tmp/uploads', filename);
    const buffer = await fs.readFile(filePath);
    const ext = path.extname(filename).toLowerCase();
    const mime = ext === '.png' ? 'image/png'
      : ext === '.webp' ? 'image/webp'
      : ext === '.avif' ? 'image/avif'
      : 'image/jpeg';

    return new NextResponse(buffer, {
      headers: {
        'Content-Type': mime,
        'Cache-Control': 'public, max-age=31536000, immutable',
      },
    });
  } catch {
    return NextResponse.json({ error: 'File not found' }, { status: 404 });
  }
}
