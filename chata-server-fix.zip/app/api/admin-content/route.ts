import { NextRequest, NextResponse } from 'next/server';
import { promises as fs } from 'fs';
import path from 'path';

const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'ChataAdmin2025!';

// Try multiple paths for data file (Docker compatibility)
async function getDataFile(): Promise<string> {
  const candidates = [
    path.join(process.cwd(), 'data', 'site-content.json'),
    '/app/data/site-content.json',
    '/tmp/data/site-content.json',
  ];
  
  for (const filePath of candidates) {
    const dir = path.dirname(filePath);
    try {
      await fs.mkdir(dir, { recursive: true });
      // Test write access
      const testFile = path.join(dir, '.write-test');
      await fs.writeFile(testFile, 'ok');
      await fs.unlink(testFile);
      return filePath;
    } catch { continue; }
  }
  // Fallback
  return '/tmp/data/site-content.json';
}

function verifyAuth(req: NextRequest): boolean {
  return req.headers.get('x-admin-token') === ADMIN_PASSWORD;
}

// GET - load content (no auth needed - frontend reads this)
export async function GET() {
  try {
    const filePath = await getDataFile();
    const raw = await fs.readFile(filePath, 'utf-8');
    return NextResponse.json(JSON.parse(raw));
  } catch {
    // File doesn't exist yet — return empty so frontend uses defaults
    return NextResponse.json({});
  }
}

// PUT - save content (auth required)
export async function PUT(req: NextRequest) {
  if (!verifyAuth(req)) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const body = await req.json();
    if (!body || typeof body !== 'object') {
      return NextResponse.json({ error: 'Invalid data' }, { status: 400 });
    }

    const filePath = await getDataFile();
    const dir = path.dirname(filePath);
    await fs.mkdir(dir, { recursive: true });

    // Backup previous version
    try {
      const existing = await fs.readFile(filePath, 'utf-8');
      const backupPath = filePath.replace('.json', `-backup-${Date.now()}.json`);
      await fs.writeFile(backupPath, existing, 'utf-8');
      
      // Keep only last 5 backups
      const files = await fs.readdir(dir);
      const backups = files
        .filter(f => f.startsWith('site-content-backup-'))
        .sort()
        .reverse();
      for (const old of backups.slice(5)) {
        await fs.unlink(path.join(dir, old)).catch(() => {});
      }
    } catch {
      // No previous file, OK
    }

    await fs.writeFile(filePath, JSON.stringify(body, null, 2), 'utf-8');
    return NextResponse.json({ success: true, savedAt: new Date().toISOString() });
  } catch (err: any) {
    console.error('Admin save error:', err);
    return NextResponse.json({ error: err.message || 'Save failed' }, { status: 500 });
  }
}
