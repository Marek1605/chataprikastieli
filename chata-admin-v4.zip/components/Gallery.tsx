'use client';

import { useState, useCallback, useEffect, useRef } from 'react';
import { useTranslations } from 'next-intl';
import Image from 'next/image';
import { cn } from '@/lib/utils';

const STORAGE_KEY = 'chata_admin_v4';

interface GalleryImage {
  id: string;
  src: string;
  alt: string;
}

const defaultGallery: GalleryImage[] = [
  { id: '1', src: '/assets/gallery-1.jpg', alt: 'Interiér chaty' },
  { id: '2', src: '/assets/gallery-2.jpg', alt: 'Obývačka' },
  { id: '3', src: '/assets/gallery-3.jpg', alt: 'Spálňa' },
  { id: '4', src: '/assets/gallery-4.jpg', alt: 'Kuchyňa' },
  { id: '5', src: '/assets/surrounding-2.jpg', alt: 'Okolie' },
  { id: '6', src: '/assets/surrounding-3.jpg', alt: 'Príroda' },
  { id: '7', src: '/assets/surrounding-4.jpg', alt: 'Výhľad' },
  { id: '8', src: '/assets/surrounding-5.jpg', alt: 'Les' },
  { id: '9', src: '/assets/surrounding-6.jpg', alt: 'Hory' },
  { id: '10', src: '/assets/surrounding-8.jpg', alt: 'Panoráma' },
];

export default function Gallery() {
  const t = useTranslations('gallery');
  const tLightbox = useTranslations('lightbox');
  
  const [images, setImages] = useState<GalleryImage[]>(defaultGallery);
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [touchStart, setTouchStart] = useState<number | null>(null);
  const [touchEnd, setTouchEnd] = useState<number | null>(null);

  // Load from localStorage
  useEffect(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const data = JSON.parse(saved);
        if (data?.gallery?.length > 0) {
          setImages(data.gallery);
        }
      }
    } catch (e) {
      console.log('Gallery: using defaults');
    }
  }, []);

  const openLightbox = useCallback((index: number) => {
    setCurrentIndex(index);
    setLightboxOpen(true);
    document.body.style.overflow = 'hidden';
  }, []);

  const closeLightbox = useCallback(() => {
    setLightboxOpen(false);
    document.body.style.overflow = '';
  }, []);

  const goToPrev = useCallback(() => {
    setCurrentIndex((prev) => (prev - 1 + images.length) % images.length);
  }, [images.length]);

  const goToNext = useCallback(() => {
    setCurrentIndex((prev) => (prev + 1) % images.length);
  }, [images.length]);

  // Keyboard
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (!lightboxOpen) return;
      if (e.key === 'Escape') closeLightbox();
      if (e.key === 'ArrowLeft') goToPrev();
      if (e.key === 'ArrowRight') goToNext();
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [lightboxOpen, closeLightbox, goToPrev, goToNext]);

  // Touch handlers
  const onTouchStart = (e: React.TouchEvent) => { setTouchEnd(null); setTouchStart(e.targetTouches[0].clientX); };
  const onTouchMove = (e: React.TouchEvent) => { setTouchEnd(e.targetTouches[0].clientX); };
  const onTouchEnd = () => {
    if (!touchStart || !touchEnd) return;
    const distance = touchStart - touchEnd;
    if (distance > 50) goToNext();
    else if (distance < -50) goToPrev();
  };

  const gridClasses = [
    'col-span-2 row-span-2', 'col-span-1 row-span-1', 'col-span-1 row-span-1',
    'col-span-1 row-span-1', 'col-span-1 row-span-1', 'col-span-2 row-span-1',
    'col-span-1 row-span-1', 'col-span-1 row-span-1', 'col-span-1 row-span-1', 'col-span-1 row-span-1',
  ];

  const renderImage = (src: string, alt: string, fill: boolean, className: string = '') => {
    if (src.startsWith('data:')) {
      return <img src={src} alt={alt} className={cn(fill ? 'absolute inset-0 w-full h-full object-cover' : 'max-w-full max-h-[85vh] object-contain rounded-lg', className)} />;
    }
    if (fill) {
      return <Image src={src} alt={alt} fill className={cn('object-cover', className)} sizes="(max-width: 640px) 50vw, 25vw" />;
    }
    return <Image src={src} alt={alt} width={1200} height={800} className={cn('max-w-full max-h-[85vh] object-contain rounded-lg', className)} />;
  };

  if (images.length === 0) return null;

  return (
    <section id="gallery" className="py-16 sm:py-20 lg:py-24 bg-white">
      <div className="container-custom">
        <header className="text-center mb-10 sm:mb-12 lg:mb-16">
          <span className="section-label">{t('label')}</span>
          <h2 className="section-title">{t('title')}</h2>
        </header>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 sm:gap-3 lg:gap-4 auto-rows-[120px] sm:auto-rows-[160px] md:auto-rows-[180px] lg:auto-rows-[200px]">
          {images.map((image, index) => (
            <article
              key={image.id}
              className={cn(
                'relative rounded-lg sm:rounded-xl overflow-hidden cursor-pointer group bg-gradient-to-br from-cream to-cream-dark',
                gridClasses[index % gridClasses.length]
              )}
            >
              <button onClick={() => openLightbox(index)} className="absolute inset-0 w-full h-full focus:outline-none">
                {renderImage(image.src, image.alt, true, 'transition-transform duration-500 group-hover:scale-105')}
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors flex items-center justify-center">
                  <span className="opacity-0 group-hover:opacity-100 transition-opacity bg-white/90 rounded-full p-2 sm:p-3">
                    <svg className="w-5 h-5 sm:w-6 sm:h-6 text-graphite" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v3m0 0v3m0-3h3m-3 0H7" />
                    </svg>
                  </span>
                </div>
              </button>
            </article>
          ))}
        </div>
      </div>

      {/* Lightbox */}
      <div
        className={cn('lightbox', lightboxOpen && 'active')}
        onClick={closeLightbox}
        onTouchStart={onTouchStart}
        onTouchMove={onTouchMove}
        onTouchEnd={onTouchEnd}
      >
        <button className="absolute top-4 right-4 z-20 p-3 bg-white/10 hover:bg-white/20 rounded-full" onClick={closeLightbox}>
          <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
        </button>
        
        <button className="hidden sm:flex absolute left-4 top-1/2 -translate-y-1/2 z-20 p-3 bg-white/10 hover:bg-white/20 rounded-full" onClick={(e) => { e.stopPropagation(); goToPrev(); }}>
          <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
        </button>
        
        <button className="hidden sm:flex absolute right-4 top-1/2 -translate-y-1/2 z-20 p-3 bg-white/10 hover:bg-white/20 rounded-full" onClick={(e) => { e.stopPropagation(); goToNext(); }}>
          <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>
        </button>
        
        <div className="relative max-w-[95vw] max-h-[85vh]" onClick={(e) => e.stopPropagation()}>
          {lightboxOpen && images[currentIndex] && renderImage(images[currentIndex].src, images[currentIndex].alt, false)}
        </div>
        
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2">
          <span className="text-white/90 bg-black/30 px-4 py-2 rounded-full">{currentIndex + 1} / {images.length}</span>
        </div>
      </div>
    </section>
  );
}
