'use client';

import { useState, useRef, useEffect } from 'react';

const ADMIN_PASSWORD = 'ChataAdmin2025!';
const STORAGE_KEY = 'chata_admin_v4';

interface GalleryImage {
  id: string;
  src: string;
  alt: string;
}

interface SiteContent {
  hero: { title: string; subtitle: string; backgroundImage: string; };
  gallery: GalleryImage[];
}

const defaultContent: SiteContent = {
  hero: {
    title: 'Únik do ticha pod horami.',
    subtitle: 'Luxusná horská chata s panoramatickým výhľadom na Malú Fatru.',
    backgroundImage: '/assets/hero.jpg',
  },
  gallery: [
    { id: '1', src: '/assets/gallery-1.jpg', alt: 'Interiér chaty' },
    { id: '2', src: '/assets/gallery-2.jpg', alt: 'Obývačka' },
    { id: '3', src: '/assets/gallery-3.jpg', alt: 'Spálňa' },
    { id: '4', src: '/assets/gallery-4.jpg', alt: 'Kuchyňa' },
    { id: '5', src: '/assets/surrounding-2.jpg', alt: 'Okolie' },
    { id: '6', src: '/assets/surrounding-3.jpg', alt: 'Príroda' },
    { id: '7', src: '/assets/surrounding-4.jpg', alt: 'Výhľad' },
    { id: '8', src: '/assets/surrounding-5.jpg', alt: 'Les' },
    { id: '9', src: '/assets/surrounding-6.jpg', alt: 'Hory' },
    { id: '10', src: '/assets/surrounding-8.jpg', alt: 'Panoráma' },
  ],
};

export default function AdminSidebar() {
  const [isAdmin, setIsAdmin] = useState(false);
  const [showLogin, setShowLogin] = useState(false);
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [hidden, setHidden] = useState(true);
  const [content, setContent] = useState<SiteContent>(defaultContent);
  const [status, setStatus] = useState('');
  const [hasChanges, setHasChanges] = useState(false);
  
  const fileRef = useRef<HTMLInputElement>(null);

  // Load from localStorage
  useEffect(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        setContent(JSON.parse(saved));
      }
      if (sessionStorage.getItem('chata_admin') === 'true') {
        setIsAdmin(true);
        setHidden(false);
      }
    } catch (e) {
      console.error('Load error:', e);
    }
  }, []);

  // Keyboard shortcut
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.ctrlKey && e.shiftKey && e.key === 'A') {
        e.preventDefault();
        if (isAdmin) setHidden(h => !h);
        else setShowLogin(true);
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [isAdmin]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === ADMIN_PASSWORD) {
      setIsAdmin(true);
      setHidden(false);
      sessionStorage.setItem('chata_admin', 'true');
      setShowLogin(false);
      setPassword('');
      setError('');
    } else {
      setError('Nesprávne heslo');
    }
  };

  const handleLogout = () => {
    setIsAdmin(false);
    setHidden(true);
    sessionStorage.removeItem('chata_admin');
  };

  const handleSave = () => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(content));
      setStatus('✅ Uložené! Refreshujem...');
      setHasChanges(false);
      setTimeout(() => window.location.reload(), 500);
    } catch (e) {
      setStatus('❌ Chyba uloženia: ' + e);
    }
  };

  const handleReset = () => {
    if (confirm('Resetovať všetko na predvolené?')) {
      localStorage.removeItem(STORAGE_KEY);
      setContent(defaultContent);
      setStatus('✅ Reset! Refreshujem...');
      setTimeout(() => window.location.reload(), 500);
    }
  };

  // UPLOAD HANDLER - hlavná funkcia
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) {
      setStatus('❌ Žiadny súbor');
      return;
    }

    setStatus(`⏳ Nahrávam: ${file.name} (${(file.size/1024).toFixed(1)} KB)...`);

    // Check size
    if (file.size > 5 * 1024 * 1024) {
      setStatus('❌ Súbor je príliš veľký (max 5MB)');
      return;
    }

    // Check type
    if (!file.type.startsWith('image/')) {
      setStatus('❌ Nie je obrázok');
      return;
    }

    const reader = new FileReader();
    
    reader.onloadstart = () => {
      setStatus('⏳ Čítam súbor...');
    };

    reader.onprogress = (event) => {
      if (event.lengthComputable) {
        const pct = Math.round((event.loaded / event.total) * 100);
        setStatus(`⏳ Načítavam: ${pct}%`);
      }
    };

    reader.onload = (event) => {
      const base64 = event.target?.result as string;
      if (!base64) {
        setStatus('❌ Prázdny výsledok');
        return;
      }

      setStatus(`✅ Načítané! Pridávam do galérie...`);
      
      const newImage: GalleryImage = {
        id: Date.now().toString(),
        src: base64,
        alt: file.name.replace(/\.[^/.]+$/, ''),
      };

      setContent(prev => ({
        ...prev,
        gallery: [...prev.gallery, newImage],
      }));

      setHasChanges(true);
      setStatus(`✅ Obrázok "${file.name}" pridaný! Klikni ULOŽIŤ.`);
    };

    reader.onerror = () => {
      setStatus('❌ Chyba čítania: ' + reader.error?.message);
    };

    reader.readAsDataURL(file);
    
    // Reset input
    e.target.value = '';
  };

  const removeImage = (id: string) => {
    setContent(prev => ({
      ...prev,
      gallery: prev.gallery.filter(img => img.id !== id),
    }));
    setHasChanges(true);
    setStatus('🗑️ Obrázok odstránený. Klikni ULOŽIŤ.');
  };

  const updateHero = (field: 'title' | 'subtitle', value: string) => {
    setContent(prev => ({
      ...prev,
      hero: { ...prev.hero, [field]: value },
    }));
    setHasChanges(true);
  };

  // ========== LOGIN BUTTON ==========
  if (!isAdmin) {
    return (
      <>
        <button
          onClick={() => setShowLogin(true)}
          className="fixed bottom-4 left-4 w-14 h-14 rounded-xl bg-gray-800 hover:bg-gray-700 flex items-center justify-center z-50 shadow-xl border-2 border-amber-500/50 text-2xl"
          title="Admin (Ctrl+Shift+A)"
        >
          ⚙️
        </button>

        {showLogin && (
          <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-[300] p-4" onClick={() => setShowLogin(false)}>
            <div className="bg-[#1a1a1a] rounded-2xl p-6 w-full max-w-sm border border-white/10" onClick={e => e.stopPropagation()}>
              <h2 className="text-white text-xl font-bold mb-4">🏔️ Admin Panel</h2>
              <form onSubmit={handleLogin}>
                <input
                  type="password"
                  value={password}
                  onChange={e => { setPassword(e.target.value); setError(''); }}
                  placeholder="Heslo..."
                  className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl mb-3 text-white text-lg"
                  autoFocus
                />
                {error && <p className="text-red-400 text-sm mb-3">⚠️ {error}</p>}
                <button type="submit" className="w-full py-3 bg-amber-500 hover:bg-amber-400 text-black font-bold rounded-xl text-lg">
                  Prihlásiť
                </button>
              </form>
            </div>
          </div>
        )}
      </>
    );
  }

  // ========== HIDDEN STATE ==========
  if (hidden) {
    return (
      <button
        onClick={() => setHidden(false)}
        className="fixed top-1/2 -translate-y-1/2 left-0 z-[200] bg-amber-500 hover:bg-amber-400 text-black w-8 py-12 rounded-r-xl shadow-xl font-bold text-lg"
      >
        ▶
      </button>
    );
  }

  // ========== MAIN SIDEBAR ==========
  return (
    <aside className="fixed top-0 left-0 h-full w-80 bg-[#111] text-white z-[200] flex flex-col shadow-2xl border-r border-amber-500/30">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-white/10 bg-gradient-to-r from-amber-600 to-orange-600">
        <span className="font-bold text-lg">🏔️ Chata Admin</span>
        <button onClick={() => setHidden(true)} className="p-2 hover:bg-black/20 rounded-lg text-xl">✕</button>
      </div>

      {/* Status */}
      {status && (
        <div className={`p-3 text-sm font-medium ${
          status.includes('✅') ? 'bg-green-600/30 text-green-300' :
          status.includes('❌') ? 'bg-red-600/30 text-red-300' :
          'bg-blue-600/30 text-blue-300'
        }`}>
          {status}
        </div>
      )}

      {/* Save Button */}
      <div className="p-3 border-b border-white/10">
        <button
          onClick={handleSave}
          className={`w-full py-4 rounded-xl font-bold text-lg transition-all ${
            hasChanges 
              ? 'bg-amber-500 hover:bg-amber-400 text-black animate-pulse' 
              : 'bg-white/10 text-white/50'
          }`}
        >
          {hasChanges ? '💾 ULOŽIŤ ZMENY' : '✓ Všetko uložené'}
        </button>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        
        {/* Hero Section */}
        <section className="space-y-3">
          <h3 className="text-amber-400 font-bold uppercase text-sm">🏠 Hero Sekcia</h3>
          
          <div>
            <label className="text-xs text-gray-400 block mb-1">Nadpis</label>
            <input
              type="text"
              value={content.hero.title}
              onChange={e => updateHero('title', e.target.value)}
              className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white"
            />
          </div>
          
          <div>
            <label className="text-xs text-gray-400 block mb-1">Podnadpis</label>
            <textarea
              value={content.hero.subtitle}
              onChange={e => updateHero('subtitle', e.target.value)}
              rows={2}
              className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white resize-y"
            />
          </div>
        </section>

        {/* Gallery Section */}
        <section className="space-y-3">
          <h3 className="text-amber-400 font-bold uppercase text-sm">🖼️ Galéria ({content.gallery.length})</h3>
          
          {/* Upload Button */}
          <button
            onClick={() => fileRef.current?.click()}
            className="w-full py-4 bg-gradient-to-r from-amber-500/20 to-orange-500/20 hover:from-amber-500/40 hover:to-orange-500/40 rounded-xl font-bold border-2 border-dashed border-amber-500 text-amber-400 transition-all"
          >
            📁 NAHRAŤ OBRÁZOK Z PC
          </button>
          <input
            ref={fileRef}
            type="file"
            accept="image/jpeg,image/png,image/gif,image/webp"
            onChange={handleFileUpload}
            className="hidden"
          />

          {/* Gallery Grid */}
          <div className="grid grid-cols-3 gap-2">
            {content.gallery.map((img) => (
              <div key={img.id} className="relative group aspect-square bg-white/5 rounded-lg overflow-hidden">
                <img
                  src={img.src}
                  alt={img.alt}
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="60" height="60"><rect fill="%23333" width="60" height="60"/><text fill="%23888" x="50%" y="50%" text-anchor="middle" dy=".3em" font-size="20">?</text></svg>';
                  }}
                />
                <button
                  onClick={() => removeImage(img.id)}
                  className="absolute top-1 right-1 w-6 h-6 bg-red-500 hover:bg-red-400 rounded-full opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-xs font-bold"
                >
                  ✕
                </button>
              </div>
            ))}
          </div>
        </section>

        {/* Settings */}
        <section className="space-y-3">
          <h3 className="text-amber-400 font-bold uppercase text-sm">⚙️ Nastavenia</h3>
          
          <button
            onClick={handleReset}
            className="w-full py-3 bg-red-600/30 hover:bg-red-600 rounded-xl font-bold transition-colors"
          >
            🗑️ Reset na predvolené
          </button>
          
          <div className="text-xs text-gray-500 space-y-1">
            <p>Heslo: <code className="bg-white/10 px-1 rounded">ChataAdmin2025!</code></p>
            <p>Skratka: <code className="bg-white/10 px-1 rounded">Ctrl+Shift+A</code></p>
          </div>
        </section>
      </div>

      {/* Footer */}
      <div className="border-t border-white/10 p-3 flex justify-between">
        <button onClick={() => window.scrollTo({top:0,behavior:'smooth'})} className="p-2 hover:bg-white/10 rounded-lg">⬆️</button>
        <button onClick={handleLogout} className="px-4 py-2 hover:bg-red-600/30 rounded-lg text-gray-400 hover:text-white">
          🚪 Odhlásiť
        </button>
      </div>
    </aside>
  );
}
