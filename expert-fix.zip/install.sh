#!/bin/bash
echo "======================================"
echo "  EXPERT FIX - Chrome Base64 Images"
echo "======================================"

cd /root/chataprikastieli

echo "[1/3] Kopirujem subory..."
cp imageUtils.ts lib/
cp SafeImage.tsx components/
cp Gallery.tsx components/
cp Atmosphere.tsx components/
cp Overview.tsx components/
cp Surroundings.tsx components/
cp Hero.tsx components/
cp Navigation.tsx components/

echo "[2/3] Cistim stare subory..."
rm -f imageUtils.ts SafeImage.tsx Gallery.tsx Atmosphere.tsx Overview.tsx Surroundings.tsx Hero.tsx Navigation.tsx install.sh

echo "[3/3] Git push..."
git add -A
git commit -m "Expert fix: Blob URL for Chrome base64 images"
git push

echo ""
echo "======================================"
echo "  HOTOVO!"
echo "======================================"
echo ""
echo "Po deployi v prehliadaci:"
echo "  1. Ctrl+F5 hard refresh"
echo "  2. Obrazky by mali fungovat v Chrome aj Firefox"
echo ""
