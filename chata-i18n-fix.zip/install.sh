#!/bin/bash
# ============================================================
# Chata pri Kaštieli - i18n Fix Installation Script
# Tento skript nainštaluje správne jazykové verzie (SK/EN/CZ/PL)
# ============================================================

set -e
cd /root/chataprikastieli

echo "🌍 Inštalujem jazykové verzie..."
echo ""

# 1. Vytvor i18n priečinok (nový pattern pre next-intl v3+)
mkdir -p i18n
echo "✅ Vytvorený priečinok i18n/"

# 2. Skopíruj routing a request config
cp -f i18n/routing.ts i18n/routing.ts.bak 2>/dev/null || true
cp -f i18n/request.ts i18n/request.ts.bak 2>/dev/null || true

# Tieto súbory musia byť už rozbalené zo ZIP-u
# Kontrola:
if [ ! -f "i18n/routing.ts" ] || [ ! -f "i18n/request.ts" ]; then
  echo "❌ Chýbajú i18n súbory! Uisti sa, že si rozbalil ZIP správne."
  exit 1
fi
echo "✅ i18n/routing.ts + i18n/request.ts"

# 3. Záloha a nahradenie middleware
cp -f middleware.ts middleware.ts.bak 2>/dev/null || true
echo "✅ middleware.ts"

# 4. Záloha a nahradenie lib/i18n.ts (backward-compatible)
mkdir -p lib
cp -f lib/i18n.ts lib/i18n.ts.bak 2>/dev/null || true
echo "✅ lib/i18n.ts (backward-compatible re-export)"

# 5. Záloha a nahradenie layout
cp -f "app/[locale]/layout.tsx" "app/[locale]/layout.tsx.bak" 2>/dev/null || true
echo "✅ app/[locale]/layout.tsx"

# 6. Jazykové súbory
mkdir -p messages
for lang in sk en cs pl; do
  cp -f "messages/${lang}.json" "messages/${lang}.json.bak" 2>/dev/null || true
done
echo "✅ messages/ (sk, en, cs, pl) — 289 kľúčov každý"

# 7. LanguageSwitcher komponent
mkdir -p components
cp -f components/LanguageSwitcher.tsx components/LanguageSwitcher.tsx.bak 2>/dev/null || true
echo "✅ components/LanguageSwitcher.tsx"

# 8. next.config — ak existuje .js verzia, premenuj
if [ -f "next.config.js" ] && [ ! -f "next.config.js.bak" ]; then
  mv next.config.js next.config.js.bak
  echo "✅ Premenovaný next.config.js → next.config.js.bak"
fi
if [ -f "next.config.ts" ] && [ ! -f "next.config.ts.bak" ]; then
  mv next.config.ts next.config.ts.bak
  echo "✅ Premenovaný next.config.ts → next.config.ts.bak"
fi
echo "✅ next.config.mjs"

echo ""
echo "============================================================"
echo "🚀 Súbory sú na mieste. Teraz:"
echo ""
echo "   cd /root/chataprikastieli"
echo "   git add -A"
echo "   git commit -m 'Fix: proper i18n with next-intl v3 routing'"
echo "   git push"
echo ""
echo "Po Coolify deployi otestuj:"
echo "   https://chataprikastieli.sk        → SK (default)"
echo "   https://chataprikastieli.sk/en     → EN"
echo "   https://chataprikastieli.sk/cs     → CZ"
echo "   https://chataprikastieli.sk/pl     → PL"
echo "============================================================"
