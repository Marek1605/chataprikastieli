import createMiddleware from 'next-intl/middleware';
import { routing } from '@/i18n/routing';

export default createMiddleware(routing);

export const config = {
  // Match all paths except Next.js internals, API routes, and static files
  matcher: [
    // Match root
    '/',
    // Match locale-prefixed paths
    '/(sk|en|cs|pl)/:path*',
    // Match all paths except internals
    '/((?!api|_next|_vercel|admin|uploads|assets|favicon\\.ico|robots\\.txt|sitemap\\.xml|.*\\..*).*)',
  ],
};
