# 🌍 Chata pri Kaštieli — i18n Fix (SK/EN/CZ/PL)

## Čo sa zmenilo

### Architektúra (next-intl v3+ pattern)
```
PRED (nefunkčné):
  lib/i18n.ts → getRequestConfig s bugmi
  middleware.ts → nesprávny config

PO (správne):
  i18n/routing.ts → defineRouting + createNavigation (source of truth)
  i18n/request.ts → getRequestConfig s validáciou
  middleware.ts → používa routing config
  lib/i18n.ts → re-export pre backward compatibility
```

### Súbory v tomto ZIP-e

| Súbor | Popis |
|-------|-------|
| `i18n/routing.ts` | Definícia locales, default locale, Link/useRouter/usePathname exports |
| `i18n/request.ts` | Server-side config pre next-intl (messages, timezone, formats) |
| `middleware.ts` | Locale detection, URL rewriting, prefix 'as-needed' |
| `lib/i18n.ts` | Backward-compatible re-export (nemeniť existujúce importy) |
| `app/[locale]/layout.tsx` | Layout s hreflang, OpenGraph per locale, font loading |
| `next.config.mjs` | Next.js config s next-intl pluginom |
| `components/LanguageSwitcher.tsx` | Dropdown prepínač jazykov pre header + footer variant |
| `messages/sk.json` | 289 kľúčov — slovenčina |
| `messages/en.json` | 289 kľúčov — angličtina |
| `messages/cs.json` | 289 kľúčov — čeština |
| `messages/pl.json` | 289 kľúčov — poľština |
| `install.sh` | Inštalačný skript |

## Inštalácia

```bash
# 1. Upload ZIP na server
# 2. Rozbaľ:
cd /root
unzip -o chata-i18n-fix.zip -d /root/chataprikastieli/

# 3. Spusti install skript:
cd /root/chataprikastieli
chmod +x install.sh
./install.sh

# 4. Push:
git add -A
git commit -m "Fix: proper i18n with next-intl v3 routing"
git push
```

## Integrácia LanguageSwitcher do Navigation

V tvojom `components/Navigation.tsx` pridaj:

```tsx
// Na začiatok súboru pridaj import:
import LanguageSwitcher from '@/components/LanguageSwitcher';

// Niekde v navbar (typicky vedľa CTA tlačidla) pridaj:
<LanguageSwitcher />

// Pre footer verziu (horizontálny zoznam):
<LanguageSwitcher variant="footer" />
```

### Príklad integrácie v navbar:

```tsx
{/* Desktop nav items */}
<div className="hidden md:flex items-center gap-6">
  <a href="#gallery">{t('nav.gallery')}</a>
  <a href="#pricing">{t('nav.pricing')}</a>
  <a href="#booking">{t('nav.booking')}</a>
  <a href="#contact">{t('nav.contact')}</a>
  
  {/* Language switcher */}
  <LanguageSwitcher />
  
  {/* CTA */}
  <a href="#booking" className="btn btn-primary">{t('nav.cta')}</a>
</div>
```

## Ako funguje routing

| URL | Jazyk | Poznámka |
|-----|-------|----------|
| `chataprikastieli.sk` | SK | Default, bez prefixu |
| `chataprikastieli.sk/en` | EN | Anglický prefix |
| `chataprikastieli.sk/cs` | CZ | Český prefix |
| `chataprikastieli.sk/pl` | PL | Poľský prefix |

### localePrefix: 'as-needed'
- SK (default) nemá prefix → čisté URL
- Ostatné jazyky majú prefix → SEO-friendly
- Middleware automaticky detekuje jazyk prehliadača

## Používanie prekladov v komponentoch

### Server component:
```tsx
import { getTranslations } from 'next-intl/server';

export default async function MyComponent() {
  const t = await getTranslations('hero');
  return <h1>{t('title')}</h1>;
}
```

### Client component:
```tsx
'use client';
import { useTranslations } from 'next-intl';

export default function MyComponent() {
  const t = useTranslations('hero');
  return <h1>{t('title')}</h1>;
}
```

### Link na inú stránku (s locale):
```tsx
import { Link } from '@/i18n/routing';

// Automaticky pridá správny locale prefix
<Link href="#booking">Rezervovať</Link>
```

## SEO

Layout automaticky generuje:
- `<html lang="sk|en|cs|pl">`
- `<link rel="alternate" hreflang="sk" href="https://chataprikastieli.sk">`
- `<link rel="alternate" hreflang="en" href="https://chataprikastieli.sk/en">`
- `<link rel="alternate" hreflang="cs" href="https://chataprikastieli.sk/cs">`
- `<link rel="alternate" hreflang="pl" href="https://chataprikastieli.sk/pl">`
- `<link rel="alternate" hreflang="x-default" href="https://chataprikastieli.sk">`
- OpenGraph s locale-specific title/description

## Troubleshooting

### Build chyba "Cannot find module '@/i18n/routing'"
→ Skontroluj že existuje `i18n/routing.ts` (nie `lib/i18n.ts` ako predtým)

### Stránka sa nenačíta po prepnutí jazyka
→ Vymaž `.next/` cache: `rm -rf .next && npm run build`

### next.config.js vs .mjs konflikt
→ Zmaz starý `next.config.js` (je zálohovaný ako `.bak`)
