'use client';

import { useState, useCallback, useEffect, useRef } from 'react';
import { useTranslations } from 'next-intl';
import Image from 'next/image';
import { cn } from '@/lib/utils';

const STORAGE_KEY = 'chata_admin_v5';

interface GalleryImage {
  id: string;
  src: string;
  alt: string;
}

const defaultGallery: GalleryImage[] = [
  { id: '1', src: '/assets/gallery-1.jpg', alt: 'Interiér chaty' },
  { id: '2', src: '/assets/gallery-2.jpg', alt: 'Obývačka' },
  { id: '3', src: '/assets/gallery-3.jpg', alt: 'Spálňa' },
  { id: '4', src: '/assets/gallery-4.jpg', alt: 'Kuchyňa' },
  { id: '5', src: '/assets/surrounding-2.jpg', alt: 'Okolie' },
  { id: '6', src: '/assets/surrounding-3.jpg', alt: 'Príroda' },
  { id: '7', src: '/assets/surrounding-4.jpg', alt: 'Výhľad' },
  { id: '8', src: '/assets/surrounding-5.jpg', alt: 'Les' },
  { id: '9', src: '/assets/surrounding-6.jpg', alt: 'Hory' },
  { id: '10', src: '/assets/surrounding-8.jpg', alt: 'Panoráma' },
];

// Helper function to save to localStorage
function saveToStorage(images: GalleryImage[]): boolean {
  try {
    const current = localStorage.getItem(STORAGE_KEY);
    const data = current ? JSON.parse(current) : {};
    data.gallery = images;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    console.log('SAVED to localStorage:', images.length, 'images');
    return true;
  } catch (e) {
    console.error('SAVE ERROR:', e);
    return false;
  }
}

// Helper function to load from localStorage
function loadFromStorage(): GalleryImage[] | null {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      const data = JSON.parse(saved);
      if (data?.gallery && Array.isArray(data.gallery) && data.gallery.length > 0) {
        console.log('LOADED from localStorage:', data.gallery.length, 'images');
        return data.gallery;
      }
    }
  } catch (e) {
    console.error('LOAD ERROR:', e);
  }
  return null;
}

export default function Gallery() {
  const t = useTranslations('gallery');
  const [images, setImages] = useState<GalleryImage[]>(defaultGallery);
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAdmin, setIsAdmin] = useState(false);
  const [editingImage, setEditingImage] = useState<GalleryImage | null>(null);
  const [showUpload, setShowUpload] = useState(false);
  const [saveStatus, setSaveStatus] = useState('');
  const fileRef = useRef<HTMLInputElement>(null);

  // Load from localStorage on mount
  useEffect(() => {
    const loaded = loadFromStorage();
    if (loaded) {
      setImages(loaded);
    }
    if (sessionStorage.getItem('chata_admin') === 'true') {
      setIsAdmin(true);
    }
  }, []);

  // Show status message
  const showStatus = (msg: string) => {
    setSaveStatus(msg);
    setTimeout(() => setSaveStatus(''), 3000);
  };

  // Update images AND save immediately
  const updateImagesAndSave = (newImages: GalleryImage[]) => {
    setImages(newImages);
    const success = saveToStorage(newImages);
    if (success) {
      showStatus('✅ Uložené!');
    } else {
      showStatus('❌ Chyba!');
    }
  };

  const deleteImage = (id: string) => {
    if (confirm('Naozaj zmazať tento obrázok?')) {
      const newImages = images.filter(img => img.id !== id);
      updateImagesAndSave(newImages);
    }
  };

  const updateImage = (id: string, updates: Partial<GalleryImage>) => {
    const newImages = images.map(img => img.id === id ? { ...img, ...updates } : img);
    updateImagesAndSave(newImages);
    setEditingImage(null);
  };

  const moveImage = (index: number, direction: 'left' | 'right') => {
    const newIndex = direction === 'left' ? index - 1 : index + 1;
    if (newIndex < 0 || newIndex >= images.length) return;
    const newImages = [...images];
    [newImages[index], newImages[newIndex]] = [newImages[newIndex], newImages[index]];
    updateImagesAndSave(newImages);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    if (file.size > 5 * 1024 * 1024) {
      alert('❌ Súbor je príliš veľký (max 5MB)');
      return;
    }

    showStatus('⏳ Nahrávam...');
    
    const reader = new FileReader();
    reader.onload = (event) => {
      const base64 = event.target?.result as string;
      if (!base64) {
        showStatus('❌ Chyba čítania!');
        return;
      }
      
      const newImage: GalleryImage = {
        id: Date.now().toString(),
        src: base64,
        alt: file.name.replace(/\.[^/.]+$/, ''),
      };
      
      const newImages = [...images, newImage];
      updateImagesAndSave(newImages);
      setShowUpload(false);
    };
    reader.onerror = () => {
      showStatus('❌ Chyba nahrávania!');
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const openLightbox = useCallback((index: number) => {
    if (isAdmin) return;
    setCurrentIndex(index);
    setLightboxOpen(true);
    document.body.style.overflow = 'hidden';
  }, [isAdmin]);

  const closeLightbox = useCallback(() => {
    setLightboxOpen(false);
    document.body.style.overflow = '';
  }, []);

  const goToPrev = useCallback(() => setCurrentIndex((prev) => (prev - 1 + images.length) % images.length), [images.length]);
  const goToNext = useCallback(() => setCurrentIndex((prev) => (prev + 1) % images.length), [images.length]);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (!lightboxOpen) return;
      if (e.key === 'Escape') closeLightbox();
      if (e.key === 'ArrowLeft') goToPrev();
      if (e.key === 'ArrowRight') goToNext();
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [lightboxOpen, closeLightbox, goToPrev, goToNext]);

  const gridClasses = ['col-span-2 row-span-2', 'col-span-1 row-span-1', 'col-span-1 row-span-1', 'col-span-1 row-span-1', 'col-span-1 row-span-1', 'col-span-2 row-span-1', 'col-span-1 row-span-1', 'col-span-1 row-span-1', 'col-span-1 row-span-1', 'col-span-1 row-span-1'];

  const renderImage = (src: string, alt: string, fill: boolean, className: string = '') => {
    if (src.startsWith('data:')) {
      return <img src={src} alt={alt} className={cn(fill ? 'absolute inset-0 w-full h-full object-cover' : 'max-w-full max-h-[85vh] object-contain rounded-lg', className)} />;
    }
    if (fill) {
      return <Image src={src} alt={alt} fill className={cn('object-cover', className)} sizes="(max-width: 640px) 50vw, 25vw" />;
    }
    return <Image src={src} alt={alt} width={1200} height={800} className={cn('max-w-full max-h-[85vh] object-contain rounded-lg', className)} />;
  };

  if (images.length === 0) return null;

  return (
    <section id="gallery" className="py-16 sm:py-20 lg:py-24 bg-white relative">
      <div className="container-custom">
        <header className="text-center mb-10 sm:mb-12 lg:mb-16">
          <span className="section-label">{t('label')}</span>
          <h2 className="section-title">{t('title')}</h2>
        </header>

        {isAdmin && (
          <div className="mb-6 p-4 bg-amber-100 border-2 border-amber-500 rounded-xl flex flex-wrap items-center gap-3">
            <span className="text-amber-800 font-bold">🔧 Admin</span>
            <button onClick={() => setShowUpload(true)} className="px-4 py-2 bg-green-500 hover:bg-green-600 text-white rounded-lg font-medium">➕ Pridať</button>
            {saveStatus && (
              <span className={cn(
                "px-3 py-1 rounded-lg text-sm font-bold animate-pulse",
                saveStatus.includes('✅') ? 'bg-green-500 text-white' :
                saveStatus.includes('❌') ? 'bg-red-500 text-white' :
                'bg-blue-500 text-white'
              )}>
                {saveStatus}
              </span>
            )}
          </div>
        )}

        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 sm:gap-3 lg:gap-4 auto-rows-[120px] sm:auto-rows-[160px] md:auto-rows-[180px] lg:auto-rows-[200px]">
          {images.map((image, index) => (
            <article key={image.id} className={cn('relative rounded-lg sm:rounded-xl overflow-hidden cursor-pointer group bg-gradient-to-br from-cream to-cream-dark', gridClasses[index % gridClasses.length], isAdmin && 'ring-2 ring-amber-400')}>
              <div className="absolute inset-0">{renderImage(image.src, image.alt, true, 'transition-transform duration-500 group-hover:scale-105')}</div>
              {!isAdmin && (
                <button onClick={() => openLightbox(index)} className="absolute inset-0 w-full h-full">
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors flex items-center justify-center">
                    <span className="opacity-0 group-hover:opacity-100 bg-white/90 rounded-full p-2 sm:p-3 text-xl">🔍</span>
                  </div>
                </button>
              )}
              {isAdmin && (
                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-2">
                  <div className="flex gap-2">
                    {index > 0 && <button onClick={() => moveImage(index, 'left')} className="w-10 h-10 bg-white hover:bg-gray-100 rounded-lg text-lg font-bold">←</button>}
                    {index < images.length - 1 && <button onClick={() => moveImage(index, 'right')} className="w-10 h-10 bg-white hover:bg-gray-100 rounded-lg text-lg font-bold">→</button>}
                  </div>
                  <div className="flex gap-2">
                    <button onClick={() => setEditingImage(image)} className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-white rounded-lg font-bold">✏️</button>
                    <button onClick={() => deleteImage(image.id)} className="px-4 py-2 bg-red-500 hover:bg-red-600 text-white rounded-lg font-bold">🗑️</button>
                  </div>
                </div>
              )}
            </article>
          ))}
        </div>
      </div>

      {editingImage && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-[400] p-4" onClick={() => setEditingImage(null)}>
          <div className="bg-white rounded-2xl p-6 w-full max-w-lg" onClick={e => e.stopPropagation()}>
            <h3 className="text-xl font-bold mb-4">✏️ Upraviť</h3>
            <div className="aspect-video bg-gray-100 rounded-lg overflow-hidden mb-4"><img src={editingImage.src} alt="" className="w-full h-full object-contain" /></div>
            <input type="text" value={editingImage.alt} onChange={e => setEditingImage({ ...editingImage, alt: e.target.value })} className="w-full px-4 py-2 border border-gray-300 rounded-lg mb-3" placeholder="Popis" />
            <div className="flex gap-3">
              <button onClick={() => updateImage(editingImage.id, { alt: editingImage.alt })} className="flex-1 py-3 bg-amber-500 text-white rounded-lg font-bold">✓ OK</button>
              <button onClick={() => setEditingImage(null)} className="flex-1 py-3 bg-gray-200 rounded-lg">Zrušiť</button>
            </div>
          </div>
        </div>
      )}

      {showUpload && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-[400] p-4" onClick={() => setShowUpload(false)}>
          <div className="bg-white rounded-2xl p-6 w-full max-w-md" onClick={e => e.stopPropagation()}>
            <h3 className="text-xl font-bold mb-4">➕ Pridať obrázok</h3>
            <button onClick={() => fileRef.current?.click()} className="w-full py-8 border-2 border-dashed border-amber-400 rounded-xl hover:bg-amber-50 flex flex-col items-center gap-2">
              <span className="text-4xl">📁</span>
              <span className="font-medium">Vybrať súbor</span>
              <span className="text-sm text-gray-500">Max 5MB</span>
            </button>
            <input ref={fileRef} type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
          </div>
        </div>
      )}

      {!isAdmin && (
        <div className={cn('lightbox', lightboxOpen && 'active')} onClick={closeLightbox}>
          <button className="absolute top-4 right-4 z-20 p-3 bg-white/10 rounded-full text-white text-2xl" onClick={closeLightbox}>✕</button>
          <button className="hidden sm:flex absolute left-4 top-1/2 -translate-y-1/2 z-20 p-3 bg-white/10 rounded-full text-white text-2xl" onClick={(e) => { e.stopPropagation(); goToPrev(); }}>←</button>
          <button className="hidden sm:flex absolute right-4 top-1/2 -translate-y-1/2 z-20 p-3 bg-white/10 rounded-full text-white text-2xl" onClick={(e) => { e.stopPropagation(); goToNext(); }}>→</button>
          <div className="relative max-w-[95vw] max-h-[85vh]" onClick={(e) => e.stopPropagation()}>{lightboxOpen && images[currentIndex] && renderImage(images[currentIndex].src, images[currentIndex].alt, false)}</div>
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2"><span className="text-white bg-black/30 px-4 py-2 rounded-full">{currentIndex + 1} / {images.length}</span></div>
        </div>
      )}
    </section>
  );
}
