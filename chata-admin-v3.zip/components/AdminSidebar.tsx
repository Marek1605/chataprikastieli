'use client';

import { useState, useRef, useEffect } from 'react';
import { useAdmin } from '@/lib/AdminContext';

type Tab = 'hero' | 'gallery' | 'pricing' | 'settings';

export default function AdminSidebar() {
  const {
    isAdmin, login, logout, content, updateContent,
    addGalleryImage, removeGalleryImage, moveGalleryImage,
    saveAll, resetToDefaults, exportData, importData, hasUnsavedChanges,
  } = useAdmin();

  const [showLogin, setShowLogin] = useState(false);
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [hidden, setHidden] = useState(true);
  const [activeTab, setActiveTab] = useState<Tab>('hero');
  const [newImageUrl, setNewImageUrl] = useState('');
  const [uploadStatus, setUploadStatus] = useState('');
  
  const fileRef = useRef<HTMLInputElement>(null);
  const importRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.ctrlKey && e.shiftKey && e.key === 'A') {
        e.preventDefault();
        isAdmin ? setHidden(h => !h) : setShowLogin(true);
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [isAdmin]);

  useEffect(() => { if (isAdmin) setHidden(false); }, [isAdmin]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (login(password)) { setShowLogin(false); setPassword(''); setError(''); }
    else { setError('Nesprávne heslo'); }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) { setUploadStatus('❌ Max 5MB'); setTimeout(() => setUploadStatus(''), 3000); return; }
    setUploadStatus('⏳ Nahrávam...');
    const reader = new FileReader();
    reader.onload = (ev) => { addGalleryImage(ev.target?.result as string, file.name); setUploadStatus('✅ Pridané!'); setTimeout(() => setUploadStatus(''), 2000); };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleExport = () => {
    const blob = new Blob([exportData()], { type: 'application/json' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob);
    a.download = `chata-backup-${new Date().toISOString().split('T')[0]}.json`; a.click();
  };

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]; if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => { importData(ev.target?.result as string) ? alert('✅ OK!') : alert('❌ Chyba'); };
    reader.readAsText(file);
  };

  // ========== LOGIN BUTTON ==========
  if (!isAdmin) {
    return (
      <>
        <button onClick={() => setShowLogin(true)} className="fixed bottom-4 left-4 w-12 h-12 rounded-xl bg-gray-800 hover:bg-gray-700 flex items-center justify-center z-50 shadow-xl border border-white/20" title="Admin (Ctrl+Shift+A)">
          <span className="text-xl">⚙️</span>
        </button>
        {showLogin && (
          <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-[300] p-4" onClick={() => setShowLogin(false)}>
            <div className="bg-[#1a1a1a] rounded-2xl p-6 w-full max-w-sm border border-white/10" onClick={e => e.stopPropagation()}>
              <h2 className="text-white text-lg font-bold mb-4">🏔️ Admin Panel</h2>
              <form onSubmit={handleLogin}>
                <input type="password" value={password} onChange={e => { setPassword(e.target.value); setError(''); }} placeholder="Heslo..." className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl mb-3 text-white" autoFocus />
                {error && <p className="text-red-400 text-xs mb-3">⚠️ {error}</p>}
                <button type="submit" className="w-full py-3 bg-amber-500 hover:bg-amber-400 text-black font-bold rounded-xl">Prihlásiť</button>
              </form>
            </div>
          </div>
        )}
      </>
    );
  }

  // ========== HIDDEN ==========
  if (hidden) {
    return <button onClick={() => setHidden(false)} className="fixed top-1/2 -translate-y-1/2 left-0 z-[200] bg-gray-900 hover:bg-gray-800 text-white w-8 py-8 rounded-r-xl shadow-xl" title="Otvoriť">▶</button>;
  }

  // ========== SIDEBAR ==========
  return (
    <>
      <aside className="fixed top-0 left-0 h-full w-80 bg-[#1a1a1a] text-white z-[200] flex flex-col shadow-2xl border-r border-white/5">
        {/* Header */}
        <div className="flex items-center justify-between p-3 border-b border-white/10">
          <span className="font-bold">🏔️ Chata Admin</span>
          <button onClick={() => setHidden(true)} className="p-2 hover:bg-white/10 rounded-lg">✕</button>
        </div>

        {/* Save */}
        <div className="p-2 border-b border-white/10">
          <button onClick={saveAll} className={`w-full py-3 rounded-xl font-bold ${hasUnsavedChanges ? 'bg-amber-500 text-black animate-pulse' : 'bg-white/10'}`}>
            {hasUnsavedChanges ? '💾 ULOŽIŤ ZMENY' : '✓ Uložené'}
          </button>
          {hasUnsavedChanges && <p className="text-xs text-amber-400 text-center mt-1">Po uložení sa stránka refreshne</p>}
        </div>

        {/* Tabs */}
        <div className="flex gap-1 p-2 border-b border-white/10">
          {[{id:'hero',icon:'🏠'},{id:'gallery',icon:'🖼️'},{id:'pricing',icon:'💰'},{id:'settings',icon:'⚙️'}].map(tab => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id as Tab)} className={`flex-1 p-2 rounded-lg ${activeTab === tab.id ? 'bg-amber-500/20 text-amber-400' : 'text-gray-500 hover:bg-white/5'}`}>{tab.icon}</button>
          ))}
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-3 space-y-4">
          {activeTab === 'hero' && (
            <>
              <Section title="🏠 Hero">
                <Field label="Nadpis" value={content.hero.title} onChange={v => updateContent('hero.title', v)} />
                <TextArea label="Podnadpis" value={content.hero.subtitle} onChange={v => updateContent('hero.subtitle', v)} />
                <ImageField label="Pozadie" value={content.hero.backgroundImage} onChange={v => updateContent('hero.backgroundImage', v)} />
              </Section>
              <Section title="📞 Kontakt">
                <Field label="Telefón" value={content.contact.phone} onChange={v => updateContent('contact.phone', v)} />
                <Field label="Email" value={content.contact.email} onChange={v => updateContent('contact.email', v)} />
              </Section>
            </>
          )}

          {activeTab === 'gallery' && (
            <Section title={`🖼️ Galéria (${content.gallery.length})`}>
              {uploadStatus && <p className={`text-xs text-center p-2 rounded ${uploadStatus.includes('✅') ? 'bg-green-500/20 text-green-400' : uploadStatus.includes('❌') ? 'bg-red-500/20 text-red-400' : 'bg-blue-500/20 text-blue-400'}`}>{uploadStatus}</p>}
              <div className="flex gap-1 mb-2">
                <input value={newImageUrl} onChange={e => setNewImageUrl(e.target.value)} placeholder="URL..." className="flex-1 px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-xs text-white" />
                <button onClick={() => { if (newImageUrl) { addGalleryImage(newImageUrl); setNewImageUrl(''); }}} className="px-3 bg-amber-500 rounded-lg text-black font-bold">+</button>
              </div>
              <button onClick={() => fileRef.current?.click()} className="w-full py-3 bg-amber-500/20 rounded-xl text-amber-400 font-medium border border-dashed border-amber-500/50 mb-3">📁 Nahrať z PC</button>
              <input ref={fileRef} type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
              <div className="grid grid-cols-3 gap-2">
                {content.gallery.map((img, i) => (
                  <div key={img.id} className="relative group aspect-square bg-white/5 rounded-lg overflow-hidden">
                    <img src={img.src} alt="" className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-black/70 opacity-0 group-hover:opacity-100 flex items-center justify-center gap-1">
                      {i > 0 && <button onClick={() => moveGalleryImage(i, i-1)} className="w-6 h-6 bg-white/20 rounded text-xs">←</button>}
                      <button onClick={() => removeGalleryImage(img.id)} className="w-6 h-6 bg-red-500 rounded text-xs">✕</button>
                      {i < content.gallery.length-1 && <button onClick={() => moveGalleryImage(i, i+1)} className="w-6 h-6 bg-white/20 rounded text-xs">→</button>}
                    </div>
                  </div>
                ))}
              </div>
            </Section>
          )}

          {activeTab === 'pricing' && (
            <>
              {(['weekend','reset','week'] as const).map((pkg,i) => (
                <Section key={pkg} title={['🌙 Víkend','⭐ Reset','📅 Týždeň'][i]}>
                  <div className="grid grid-cols-2 gap-2">
                    <Field label="Noci" type="number" value={String(content.pricing[pkg].nights)} onChange={v => updateContent(`pricing.${pkg}.nights`, parseInt(v)||0)} />
                    <Field label="€" type="number" value={String(content.pricing[pkg].price)} onChange={v => updateContent(`pricing.${pkg}.price`, parseInt(v)||0)} />
                  </div>
                </Section>
              ))}
            </>
          )}

          {activeTab === 'settings' && (
            <>
              <Section title="💾 Záloha">
                <button onClick={handleExport} className="w-full py-3 bg-blue-600 rounded-xl font-bold mb-2">📥 Export JSON</button>
                <button onClick={() => importRef.current?.click()} className="w-full py-3 bg-white/5 rounded-xl border border-dashed border-white/20">📤 Import</button>
                <input ref={importRef} type="file" accept=".json" onChange={handleImport} className="hidden" />
              </Section>
              <Section title="⚠️ Reset">
                <button onClick={() => confirm('Reset všetko?') && resetToDefaults()} className="w-full py-3 bg-red-600/50 hover:bg-red-600 rounded-xl font-bold">🗑️ Na predvolené</button>
              </Section>
              <Section title="ℹ️ Info">
                <p className="text-xs text-gray-400">Heslo: <code className="bg-white/10 px-1 rounded">ChataAdmin2025!</code></p>
                <p className="text-xs text-gray-400 mt-1">Skratka: <code className="bg-white/10 px-1 rounded">Ctrl+Shift+A</code></p>
              </Section>
            </>
          )}
        </div>

        {/* Footer */}
        <div className="border-t border-white/10 p-2 flex justify-between">
          <button onClick={() => window.scrollTo({top:0,behavior:'smooth'})} className="p-2 hover:bg-white/10 rounded-lg">⬆️</button>
          <button onClick={logout} className="px-4 py-2 hover:bg-red-600/30 rounded-lg text-gray-400 hover:text-white">🚪 Odhlásiť</button>
        </div>
      </aside>

      {hasUnsavedChanges && <div className="fixed bottom-4 right-4 z-[190] bg-amber-500 text-black px-4 py-2 rounded-xl font-bold shadow-xl">⚠️ Neuložené!</div>}
    </>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return <div className="space-y-2"><p className="text-xs font-bold text-gray-400 uppercase">{title}</p>{children}</div>;
}

function Field({ label, value, onChange, type = 'text' }: { label: string; value: string; onChange: (v: string) => void; type?: string }) {
  return (
    <div>
      <label className="text-[10px] text-gray-400 block mb-1">{label}</label>
      <input type={type} value={value} onChange={e => onChange(e.target.value)} className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-sm text-white focus:ring-2 focus:ring-amber-500" />
    </div>
  );
}

function TextArea({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <div>
      <label className="text-[10px] text-gray-400 block mb-1">{label}</label>
      <textarea value={value} onChange={e => onChange(e.target.value)} rows={3} className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-sm text-white resize-y focus:ring-2 focus:ring-amber-500" />
    </div>
  );
}

function ImageField({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  const [showUrl, setShowUrl] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]; if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => onChange(ev.target?.result as string);
    reader.readAsDataURL(file);
  };
  return (
    <div>
      <label className="text-[10px] text-gray-400 block mb-1">{label}</label>
      <div className="aspect-video bg-white/5 rounded-lg overflow-hidden mb-2"><img src={value} alt="" className="w-full h-full object-cover" /></div>
      <div className="flex gap-2">
        <button onClick={() => setShowUrl(!showUrl)} className="flex-1 py-2 bg-white/5 rounded-lg text-xs">{showUrl ? '✕' : '🔗 URL'}</button>
        <button onClick={() => fileRef.current?.click()} className="flex-1 py-2 bg-amber-500/20 text-amber-400 rounded-lg text-xs">📁 Nahrať</button>
        <input ref={fileRef} type="file" accept="image/*" onChange={handleFile} className="hidden" />
      </div>
      {showUrl && <input type="text" value={value} onChange={e => onChange(e.target.value)} className="w-full mt-2 px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-sm text-white" />}
    </div>
  );
}
